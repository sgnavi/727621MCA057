import React from "react";
import { useEffect, useState } from "react";

export default function Home() {
  const [user, setUser] = useState([]);
  const data = {
    companyname: "Metro Central",
    clientID: "1ccfe262-5565-4ac7-a475-8a76417225ea",
    ownerName: "Navin",
    ownerEmail: "sgnavin2312@gmail.com",
    rollNo: "21MCA057",
    clientSecret: "QyazOWcrSbAuTepB",
  };


  const fetchData = () => {
     fetch("http://104.211.219.98/train/auth", {
      mode: "no-cors",
      method: "POST",
      body: JSON.stringify(data),
    }).then(res => console.log(res.data))
    //   .then((res) => {
    //     res.json()
    //    console.log(res) 
    //   })
    //   .then((data) => setUser(data));
  };

  useEffect(() => {
   const res =  fetchData();
   console.log(res)
  }, []);

  return (
    <div className="container">
      <h3 className="App">Central Train Status</h3>
      <div className="row">
        <div className="col-md-12">
          <input
            placeholder="Search Here For Train"
            type="text"
            className="form-control"
          ></input>
        </div>
      </div>
    </div>
  );
}
