 import React from 'react'
import { Link } from 'react-router-dom'
 
 export default function NavBar() {
   return (
     <nav>
        <Link className='ul' to='/'>Home</Link>
        <Link className='ul' to='/n'>NextPage</Link>
     </nav>
   )
 }
 