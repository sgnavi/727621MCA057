import React from 'react'

export default function NextPage() {
  return (
    <div>
      next
    </div>
  )
}
