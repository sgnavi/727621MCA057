 import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from './component/Home'
import NextPage from './component/NextPage'
import NavBar from './component/NavBar';
import 'bootstrap/dist/css/bootstrap.css';
// Put any other imports below so that CSS from your
// components takes precedence over default styles.
 
 export default function App() {
   return (
      <>
      <BrowserRouter>
      <NavBar/>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/n' element={<NextPage/>}/>
      </Routes>
      </BrowserRouter>
      </>
   );
 }
 